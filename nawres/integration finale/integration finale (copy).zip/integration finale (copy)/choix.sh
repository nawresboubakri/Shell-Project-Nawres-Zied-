#!/bin/bash
menu_choix()
{
	echo
	echo
	echo
	echo "			******************Choisir un menu : ******************"
	echo
	echo
			echo "1) -NCURSUS"
			echo "2) -YAD "
			read choix
}
